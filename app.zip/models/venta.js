'use strict'

var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema;

var ventaShema = Schema({
    id: {type: Number, required: true},
    compania: {type: Schema.ObjectId, ref: 'compania', required: true}, 
    sucursal: {type: Schema.ObjectId, ref: 'sucursal', required: true}, 
    cliente: {type: Schema.ObjectId, ref: 'cliente', required: true},
    vendedor: {type: Schema.ObjectId, ref: 'usuario', required: true}, 
    caja: {type: Schema.ObjectId, ref: 'caja', required: true},
    itbis: {type: Schema.ObjectId, ref: 'itbis', required: true},
    doctor: {type: Schema.ObjectId, ref: 'doctor', required: true},
    importe: {type: Number, required: true},
    impuestos: {type: Number, required: true},
    descuentos: {type: Number, required: true},
    fecha_vencimiento: {type: Date, required: true},
    fecha_contabilizacion: {type: Date, required: true},
    comentarios: {type: String, required: true}, 
    moneda: {type: Schema.ObjectId, ref: 'moneda', required: true},
    tipo_cambio: {type: Schema.ObjectId, ref: 'tasa_cambio', required: true},
    tipo_comprobante: {type: Schema.ObjectId, ref: 'tipos_comprobante', required: true},
    ncf: {type: String, required: true},
    fecha_vencimiento_ncf: {type: Date, required: true}, 
    rnc: {type: String, required: true},
    tipo_ingreso: {type: Schema.ObjectId, ref: 'tipo_ingreso', required: true},
    medio_pago: {type: Schema.ObjectId, ref: 'medio_pago', required: true},
    estatus: {type: Boolean, required: true},
    cancelada: {type: Boolean, default: false, required: true},
    createdAt: {type: Date, default: Date.now, require:true},
});

autoIncrement.initialize(mongoose.connection);
ventaShema.plugin(autoIncrement.plugin, {model: 'venta', field: 'id', startAt: 1});
module.exports = mongoose.model('venta', ventaShema);