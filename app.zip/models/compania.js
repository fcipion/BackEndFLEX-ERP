'use strict'

var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema;

var companiaShema = Schema({
    id: {type: Number, required: true},
    nombre: {type: String, required: true},
    descripcion: {type: String, required: true},
    rnc: {type: String, required: true},
    direccion: {type: String, required: true},
    email: {type: String, required: true},
    telefono: {type: String, required: true},
    celular: {type: String, required: true},
    whatsapp: {type: String, required: true},
    mision: {type: String, required: true},
    vision: {type: String, required: true},
    valores: {type: String, required: true},
    estatus: {type: Boolean, required: true},
    fecha_establecida: {type: Date, require:true},
    logo: {type: String, required: true},  
    sitio_web: {type: String, required: true},
    moneda_curso: {type: Schema.ObjectId, ref: 'moneda', required: true},
    moneda_paralela: {type: Schema.ObjectId, ref: 'moneda', required: true},   
    createdAt: {type: Date, default: Date.now, require:true},
});

autoIncrement.initialize(mongoose.connection);
companiaShema.plugin(autoIncrement.plugin, {model: 'compania', field: 'id', startAt: 1});
module.exports = mongoose.model('compania', companiaShema);