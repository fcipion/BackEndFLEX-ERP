'use strict'

var fs = require('fs');
var path = require('path');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../helpers/jwt');

var Pagina = require('../models/pagina');
var Rol_Aceeso = require('../models/rol_acceso');

var Venta = require('../models/venta');

//Ventas
const registro_venta = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'facturas_ventas'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
                if(accesos.acceso[0].add == true){
                    var data = req.body;

                    let reg = await Venta.create(data);

                    //log de Registro
                    LogController.log_create("facturas_ventas", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({data:reg});
                }
                else{
                    res.status(500).send({message: 'NoAccess'});
                }
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const listar_venta = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'facturas_ventas'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                let filtro = req.params['filtro'];

                let reg = await Venta.find({descripcion: new RegExp(filtro, 'i')}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");
                res.status(200).send({data:reg});
                
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const eliminar_venta = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'facturas_ventas'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].delete == true){
                var id = req.params['id'];

                let reg = await Venta.findByIdAndRemove({_id:id});

                //Log de eliminar
                LogController.log_delete("facturas_ventas", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:reg});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const obtener_venta = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'facturas_ventas'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                var id = req.params['id'];
                try {
                    var reg = await Venta.findById({_id:id}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");

                    res.status(200).send({data:reg});
                } 
                catch (error) {
                    res.status(200).send({data:undefined});
                }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }
        else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const actualizar_venta = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'facturas_ventas'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].edit == true){
                let id = req.params['id'];
                var data = req.body;

                let reg = await Venta.findByIdAndUpdate({_id:id},data);

                //Log de actualizar
                LogController.log_edit("facturas_ventas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:data});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}


module.exports = {
    registro_venta,
    listar_venta,
    eliminar_venta,
    obtener_venta,
    actualizar_venta,
}