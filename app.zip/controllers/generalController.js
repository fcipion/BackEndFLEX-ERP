'use strict'

var path = require('path');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../helpers/jwt');

var Log = require('../models/log');
var Log_Item = require('../models/log_item');
var Ticket = require('../models/ticket');

const log_create = async function(modelo, data, usuario, compania, id){
    try {
        //Log
        var log_data = data;
        log_data.usuario =  usuario;
        log_data.type = 'create';
        log_data.date = Date.now();

        var log_object = {
            id: id,
            changes: log_data
        }

        var log_item = await Log_Item.create(log_object);
        var log_header = {
            modelo: modelo,
            compania: compania,
            log_item: log_item._id
        }

        var log_header_find = await Log.findOne({compania: compania, modelo:modelo});
        if(log_header_find == null){
            await Log.create(log_header);
        }
        //Fin Log
    } 
    catch (error) {
        res.status(400).send({message: error});
    }
}

const log_delete = async function(modelo, usuario, compania, id){
    try {
        //Log
        var log_item = [];
        var log_data = {};
        log_data.usuario =  usuario;
        log_data.type = 'delete';
        log_data.date = Date.now();

        var log_object = {
            id: id,
            changes: log_data
        }

        var log_find = await Log_Item.findOne({id:id});
        if(log_find == null){
             log_item = await Log_Item.create(log_object);
        }
        else{
            log_item = await Log_Item.findByIdAndUpdate({_id:log_find._id},{ $push: { changes: log_data}});
        }

        var log_header = {
            modelo: modelo,
            compania: compania,
            log_item: log_item._id
        }

        var log_header_find = await Log.findOne({compania: compania, modelo:modelo});
        if(log_header_find == null){
            await Log.create(log_header);
        }
        //Fin Log
    } 
    catch (error) {
        console.log(error);
    }
}

const log_edit = async function(modelo, data, usuario, compania, id){
    try {
        //Log
        var log_item = [];
        var log_data = data;
        log_data.usuario = usuario;
        log_data.type = 'edit';
        log_data.date = Date.now();

        var log_object = {
            id: id,
            changes: log_data
        }

        var log_find = await Log_Item.findOne({id:id});
        if(log_find == null){
             log_item = await Log_Item.create(log_object);
        }
        else{
            log_item = await Log_Item.findByIdAndUpdate({_id:log_find._id},{ $push: { changes: log_data}});
        }

        var log_header = {
            modelo: modelo,
            compania: compania,
            log_item: log_item._id
        }

        var log_header_find = await Log.findOne({compania: compania, modelo:modelo});
        if(log_header_find == null){
            await Log.create(log_header);
        }
        //Fin Log
    } 
    catch (error) {
        console.log(error);
    }
}

module.exports = {
    log_create,
    log_delete,
    log_edit
}