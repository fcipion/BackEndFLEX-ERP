'use strict'

var fs = require('fs');
var path = require('path');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../helpers/jwt');

var Pagina = require('../models/pagina');
var Rol_Aceeso = require('../models/rol_acceso');
var Log = require('../models/log');
var Log_Item = require('../models/log_item');

var LogController = require('../controllers/generalController');

var Tipos_comprobantes = require('../models/tipos_comprobante');
var Rango_comprobante = require('../models/rango_comprobante');
var Monedas = require('../models/monedas');
var Tasa_cambio = require('../models/tasa_cambio');
var Tipo_producto = require('../models/tipo_producto');
var Clase_producto = require('../models/clase_producto');
var Unidad_medida = require('../models/unidad_medida');
var Caja = require('../models/caja');
var Medio_pago = require('../models/medio_pago');
var Banco = require('../models/banco');
var Tarjeta = require('../models/tarjeta');
var Turno = require('../models/turno');
var Proceso_caja = require('../models/proceso_caja');
var Tipo_documento = require('../models/tipo_documento');
var Tipo_cliente = require('../models/tipo_cliente');
var Termino_pago = require('../models/termino_pago');
var Itbis = require('../models/itbis');
var Tipo_ingreso = require('../models/tipo_ingreso');

var Venta = require('../models/venta');
var Cliente = require('../models/cliente');
var Companias = require('../models/compania');
var Determinacion_precio = require('../models/determinacion_precio');
var Proveedor = require('../models/proveedor');
var Producto = require('../models/producto');
var Doctor = require('../models/doctor');

//tipos_comprobante
const registro_tipo_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Tipos_comprobantes.create(data);

                //log de Registro
                LogController.log_create("tipos_comprobantes", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tipos_comprobantes = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Tipos_comprobantes.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tipo_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var ventas_arr = [];

                ventas_arr = await Venta.find({ tipo_comprobante: id });

                if (ventas_arr.length == 0) {
                    let reg = await Tipos_comprobantes.findByIdAndRemove({ _id: id });
                    //Log de eliminar
                    LogController.log_delete("tipos_comprobantes", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de comprobante, existen (' + ventas_arr.length + ') ventas con este tipo de comprobante', data: undefined });
                }

            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tipo_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Tipos_comprobantes.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tipo_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Tipos_comprobantes.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("tipos_comprobantes", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//rango_comprobante
const registro_rango_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'rangos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Rango_comprobante.create(data);

                //log de Registro
                LogController.log_create("rangos_comprobantes", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_rango_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'rangos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Rango_comprobante.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_rango_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'rangos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Rango_comprobante.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("rangos_comprobantes", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_rango_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'rangos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Rango_comprobante.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_rango_comprobante = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'rangos_comprobantes' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Rango_comprobante.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("rangos_comprobantes", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Monedas
const registro_moneda = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'monedas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {

                var data = req.body;
                data.compania = req.user.compania;
                let reg = await Monedas.create(data);

                //Log
                LogController.log_create("monedas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_monedas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'monedas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Monedas.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_moneda = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'monedas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var ventas_arr = [];
                var clientes_arr = [];
                var companias_arr = [];
                var determinacion_precio_arr = [];
                var proveedor_arr = [];
                var tasa_cambio_arr = [];
                //validar si existen ventas
                ventas_arr = await Venta.find({ moneda: id });
                if (ventas_arr.length == 0) {

                    //validar si existen clientes
                    clientes_arr = await Cliente.find({ moneda_curso: id });
                    if (clientes_arr.length == 0) {

                        //validar si existen companias
                        companias_arr = await Companias.find({ $or: [{ moneda_curso: id }, { moneda_paralela: id }] });
                        if (companias_arr.length == 0) {

                            //validar si existen Determinacion_precio
                            determinacion_precio_arr = await Determinacion_precio.find({ moneda: id });
                            if (determinacion_precio_arr.length == 0) {

                                //validar si existen proveedores
                                proveedor_arr = await Proveedor.find({ moneda_curso: id });
                                if (proveedor_arr.length == 0) {

                                    let reg = await Monedas.findByIdAndRemove({ _id: id });
                                    //Log de eliminar
                                    LogController.log_delete("monedas", req.user.sub, req.user.compania, reg._id);

                                    res.status(200).send({ data: reg });
                                }
                                else {
                                    res.status(200).send({ code: 1004, message: 'No se puede eliminar la moneda, existen (' + proveedor_arr.length + ') proveedores con esta moneda', data: undefined });
                                }
                            }
                            else {
                                res.status(200).send({ code: 1004, message: 'No se puede eliminar la moneda, existen (' + determinacion_precio_arr.length + ') determinaciones de precio ccon esta moneda', data: undefined });
                            }
                        }
                        else {
                            res.status(200).send({ code: 1004, message: 'No se puede eliminar la moneda, existen (' + companias_arr.length + ') compañía con esta moneda', data: undefined });
                        }
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar la moneda, existen (' + clientes_arr.length + ') clientes con esta moneda', data: undefined });
                    }
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar la moneda, existen (' + ventas_arr.length + ') ventas con esta moneda', data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_moneda = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'monedas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Monedas.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_moneda = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'monedas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Monedas.findByIdAndUpdate({ _id: id }, data);

                //Log
                LogController.log_edit("monedas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//tasa_cambio
const registro_tasa_cambio = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tasa_cambio' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {

                var data = req.body;
                data.compania = req.user.compania;
                let reg = await Tasa_cambio.create(data);

                //log de Registro
                LogController.log_create("tasa_cambio", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tasa_cambio = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tasa_cambio' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Tasa_cambio.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tasa_cambio = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tasa_cambio' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var ventas_arr = [];

                ventas_arr = await Venta.find({ tipo_cambio: id });

                if (ventas_arr.length == 0) {
                    let reg = await Tasa_cambio.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("tasa_cambio", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar la tasa de cambio, existen (' + ventas_arr.length + ') ventas con esta tasa de cambio', data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tasa_cambio = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tasa_cambio' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Tasa_cambio.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tasa_cambio = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tasa_cambio' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Tasa_cambio.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("tasa_cambio", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Tipo_Producto
const registro_tipo_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Tipo_producto.create(data);

                //log de Registro
                LogController.log_create("tipo_producto", data, req.user.sub, req.user.compania, reg._id);


                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tipo_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Tipo_producto.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tipo_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var productos_arr = [];

                productos_arr = await Producto.find({ tipo_producto: id });

                if (productos_arr.length == 0) {
                    let reg = await Tipo_producto.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("tipo_producto", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de producto, existen (' + productos_arr.length + ') productos con este tipo de producto', data: undefined });
                }


            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tipo_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Tipo_producto.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tipo_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });

            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                data.compania = req.user.compania;
                let reg = await Tipo_producto.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("tipo_producto", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//clase_producto
const registro_clase_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'clase_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Clase_producto.create(data);

                //log de Registro
                LogController.log_create("clase_producto", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_clase_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'clase_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Clase_producto.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_clase_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'clase_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var productos_arr = [];

                productos_arr = await Producto.find({ clase_producto: id });

                if (productos_arr.length == 0) {
                    let reg = await Clase_producto.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("clase_producto", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar la clase de producto, existen (' + productos_arr.length + ') producto con esta clase de producto', data: undefined });
                }

            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_clase_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'clase_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Clase_producto.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_clase_producto = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'clase_producto' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Clase_producto.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("clase_producto", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//unidad_medida
const registro_unidad_medida = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'unidad_medida' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Unidad_medida.create(data);

                //log de Registro
                LogController.log_create("unidad_medida", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_unidad_medida = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'unidad_medida' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Unidad_medida.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_unidad_medida = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'unidad_medida' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Unidad_medida.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("unidad_medida", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_unidad_medida = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'unidad_medida' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                var reg = await Unidad_medida.findById({ _id: id });

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_unidad_medida = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'unidad_medida' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Unidad_medida.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("unidad_medida", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Caja
const registro_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'cajas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Caja.create(data);

                //log de Registro
                LogController.log_create("cajas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'cajas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Caja.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'cajas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var ventas_arr = [];
                var proceso_caja_arr = [];

                //Buscar Ventas
                ventas_arr = await Venta.find({ caja: id });
                if (ventas_arr.length == 0) {

                    //Buscar Proceso de caja
                    proceso_caja_arr = await Proceso_caja.find({ caja: id });
                    if (proceso_caja_arr.length == 0) {
                        let reg = await Caja.findByIdAndRemove({ _id: id });

                        //Log de eliminar
                        LogController.log_delete("cajas", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({ data: reg });
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar la caja, existen (' + proceso_caja_arr.length + ') proceso_caja con esta caja', data: undefined });
                    }
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar la caja, existen (' + ventas_arr.length + ') ventas con esta caja', data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'cajas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Caja.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'cajas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Caja.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("cajas", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Medio Pago
const registro_medio_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'medios_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Medio_pago.create(data);

                //log de Registro
                LogController.log_create("medios_pago", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_medio_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'medios_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Medio_pago.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_medio_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'medios_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var ventas_arr = [];

                ventas_arr = await Venta.find({ medio_pago: id });

                if (ventas_arr.length == 0) {
                    let reg = await Medio_pago.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("medios_pago", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar el medios de pago, existen (' + ventas_arr.length + ') ventas con este medios de pago', data: undefined });
                }

            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_medio_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'medios_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Medio_pago.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_medio_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'medios_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Medio_pago.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("medios_pago", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Bancos
const registro_banco = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'bancos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Banco.create(data);

                //log de Registro
                LogController.log_create("bancos", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_banco = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'bancos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Banco.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_banco = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'bancos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Banco.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("bancos", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_banco = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'bancos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Banco.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_banco = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'bancos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Banco.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("bancos", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Tarjeta
const registro_tarjetas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tarjetas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Tarjeta.create(data);

                //log de Registro
                LogController.log_create("tarjetas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tarjetas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tarjetas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Tarjeta.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tarjetas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tarjetas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Tarjeta.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("tarjetas", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tarjetas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tarjetas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Tarjeta.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tarjetas = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tarjetas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Tarjeta.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("tarjetas", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Turnos
const registro_turnos = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'turnos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Turno.create(data);

                //log de Registro
                LogController.log_create("turnos", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_turnos = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'turnos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Turno.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_turnos = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'turnos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                var proceso_caja_arr = [];

                proceso_caja_arr = await Proceso_caja.find({ turno: id });

                if (proceso_caja_arr.length == 0) {
                    let reg = await Turno.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("turnos", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar el turno, existen (' + proceso_caja_arr.length + ') proceso caja con este turno', data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_turnos = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'turnos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Turno.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_turnos = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'turnos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Turno.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("turnos", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Proceso_caja
const registro_proceso_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'proceso_caja' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Proceso_caja.create(data);

                //log de Registro
                LogController.log_create("proceso_caja", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_proceso_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'proceso_caja' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Proceso_caja.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_proceso_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'proceso_caja' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Proceso_caja.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("proceso_caja", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_proceso_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'proceso_caja' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Proceso_caja.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_proceso_caja = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'proceso_caja' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Proceso_caja.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("proceso_caja", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Tipos de documentos
const registro_tipo_documento = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_documento' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Tipo_documento.create(data);

                    //log de Registro
                    LogController.log_create("tipo_documento", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({ message: error });
    }
}

const listar_tipo_documento = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_documento' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Tipo_documento.find({ descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tipo_documento = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_documento' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];

                    var clientes_arr = [];
                    var doctores_arr = [];
                    var proveedores_arr = [];

                    //Buscar clientes
                    clientes_arr = await Cliente.find({ tipo_documento: id });
                    if (clientes_arr.length == 0) {

                        //Buscar doctores
                        doctores_arr = await Doctor.find({ tipo_documento: id });
                        if (doctores_arr.length == 0) {

                            //Buscar proveedores
                            proveedores_arr = await Proveedor.find({ tipo_documento: id });
                            if (proveedores_arr.length == 0) {
                                let reg = await Tipo_documento.findByIdAndRemove({ _id: id });

                                //Log de eliminar
                                LogController.log_delete("tipo_documento", req.user.sub, req.user.compania, reg._id);

                                res.status(200).send({ data: reg });
                            }
                            else {
                                res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de docuemnto, existen (' + proveedores_arr.length + ') proveedores con  este tipo de docuemnto', data: undefined });
                            }
                        }
                        else {
                            res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de docuemnto, existen (' + doctores_arr.length + ') doctores con  este tipo de docuemnto', data: undefined });
                        }
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de docuemnto, existen (' + clientes_arr.length + ') clientes con este tipo de docuemnto', data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tipo_documento = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_documento' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        var reg = await Tipo_documento.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tipo_documento = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_documento' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Tipo_documento.findByIdAndUpdate({ _id: id }, data);

                    //Log de actualizar
                    LogController.log_edit("tipo_documento", data, req.user.sub, req.user.compania, reg._id);
                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Tipo de cliente
const registro_tipo_cliente = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_cliente' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Tipo_cliente.create(data);

                    //log de Registro
                    LogController.log_create("tipo_cliente", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tipo_cliente = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_cliente' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Tipo_cliente.find({ descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tipo_cliente = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_cliente' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];

                    var cliente_arr = [];

                    cliente_arr = await Cliente.find({ tipo_cliente: id });

                    if (cliente_arr.length == 0) {
                        let reg = await Tipo_cliente.findByIdAndRemove({ _id: id });

                        //Log de eliminar
                        LogController.log_delete("tipo_cliente", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({ data: reg });
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar el tipo de cliente, existen (' + cliente_arr.length + ') clientes caja con este tipo de cliente', data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tipo_cliente = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_cliente' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        var reg = await Tipo_cliente.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tipo_cliente = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_cliente' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Tipo_cliente.findByIdAndUpdate({ _id: id }, data);

                    //Log de actualizar
                    LogController.log_edit("tipo_cliente", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Termino de pago
const registro_termino_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'termino_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Termino_pago.create(data);

                    //log de Registro
                    LogController.log_create("termino_pago", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_termino_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'termino_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Termino_pago.find({ descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_termino_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'termino_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];
                    
                    var clientes_arr = [];
                    var proveedores_arr = [];

                    //Buscar clientes
                    clientes_arr = await Cliente.find({ termino_pago: id });
                    if (clientes_arr.length == 0) {

                        //Buscar proveedores
                        proveedores_arr = await Proveedor.find({ termino_pago: id });
                        if (proveedores_arr.length == 0) {

                            let reg = await Termino_pago.findByIdAndRemove({ _id: id });

                            //Log de eliminar
                            LogController.log_delete("termino_pago", req.user.sub, req.user.compania, reg._id);

                            res.status(200).send({ data: reg });
                        }
                        else {
                            res.status(200).send({ code: 1004, message: 'No se puede eliminar el termino de pago, existen (' + clientes_arr.length + ') clientes con este termino de pago', data: undefined });
                        }
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar el termino de pago, existen (' + clientes_arr.length + ') clientes con este termino de pago', data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_termino_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'termino_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {

                        var reg = await Termino_pago.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_termino_pago = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'termino_pago' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Termino_pago.findByIdAndUpdate({ _id: id }, data);

                    //Log de actualizar
                    LogController.log_edit("termino_pago", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Itbis 
const registro_itbis = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'itbis' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Itbis.create(data);

                    //log de Registro
                    LogController.log_create("itbis", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_itbis = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'itbis' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Itbis.find({ descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_itbis = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'itbis' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];

                    var ventas_arr = [];

                    ventas_arr = await Venta.find({ itbis: id });

                    if (ventas_arr.length == 0) {
                        let reg = await Itbis.findByIdAndRemove({ _id: id });

                        //Log de eliminar
                        LogController.log_delete("itbis", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({ data: reg });
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar el Itbis, existen (' + ventas_arr.length + ') ventas con este Itbis', data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_itbis = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'itbis' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        var reg = await Itbis.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_itbis = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'itbis' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Itbis.findByIdAndUpdate({ _id: id }, data);

                    //Log de actualizar
                    LogController.log_edit("itbis", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

//tipo_ingreso 
const registro_tipo_ingreso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_ingreso' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Tipo_ingreso.create(data);

                    //log de Registro
                    LogController.log_create("tipo_ingreso", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_tipo_ingreso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_ingreso' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Tipo_ingreso.find({ descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_tipo_ingreso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_ingreso' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];

                    var ventas_arr = [];

                    ventas_arr = await tipo_ingreso.find({ itbis: id });

                    if (ventas_arr.length == 0) {
                        let reg = await Tipo_ingreso.findByIdAndRemove({ _id: id });

                        //Log de eliminar
                        LogController.log_delete("tipo_ingreso", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({ data: reg });
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar el Tipo de ingreso, existen (' + ventas_arr.length + ') ventas con este Tipo de ingreso', data: undefined });
                    }

                    
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_tipo_ingreso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_ingreso' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        var reg = await Tipo_ingreso.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_tipo_ingreso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'tipo_ingreso' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Tipo_ingreso.findByIdAndUpdate({ _id: id }, data);

                    //Log de actualizar
                    LogController.log_edit("tipo_ingreso", data, req.user.sub, req.user.compania, reg._id);
                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

module.exports = {
    registro_tipo_comprobante,
    listar_tipos_comprobantes,
    eliminar_tipo_comprobante,
    obtener_tipo_comprobante,
    actualizar_tipo_comprobante,

    registro_rango_comprobante,
    listar_rango_comprobante,
    eliminar_rango_comprobante,
    obtener_rango_comprobante,
    actualizar_rango_comprobante,

    registro_moneda,
    listar_monedas,
    eliminar_moneda,
    obtener_moneda,
    actualizar_moneda,

    registro_tasa_cambio,
    listar_tasa_cambio,
    eliminar_tasa_cambio,
    obtener_tasa_cambio,
    actualizar_tasa_cambio,

    registro_tipo_producto,
    listar_tipo_producto,
    eliminar_tipo_producto,
    obtener_tipo_producto,
    actualizar_tipo_producto,

    registro_clase_producto,
    listar_clase_producto,
    eliminar_clase_producto,
    obtener_clase_producto,
    actualizar_clase_producto,

    registro_unidad_medida,
    listar_unidad_medida,
    eliminar_unidad_medida,
    obtener_unidad_medida,
    actualizar_unidad_medida,

    registro_caja,
    listar_caja,
    eliminar_caja,
    obtener_caja,
    actualizar_caja,

    registro_medio_pago,
    listar_medio_pago,
    eliminar_medio_pago,
    obtener_medio_pago,
    actualizar_medio_pago,

    registro_banco,
    listar_banco,
    eliminar_banco,
    obtener_banco,
    actualizar_banco,

    registro_tarjetas,
    listar_tarjetas,
    eliminar_tarjetas,
    obtener_tarjetas,
    actualizar_tarjetas,

    registro_turnos,
    listar_turnos,
    eliminar_turnos,
    obtener_turnos,
    actualizar_turnos,

    registro_proceso_caja,
    listar_proceso_caja,
    eliminar_proceso_caja,
    obtener_proceso_caja,
    actualizar_proceso_caja,

    registro_tipo_documento,
    listar_tipo_documento,
    eliminar_tipo_documento,
    obtener_tipo_documento,
    actualizar_tipo_documento,

    registro_tipo_cliente,
    listar_tipo_cliente,
    eliminar_tipo_cliente,
    obtener_tipo_cliente,
    actualizar_tipo_cliente,

    registro_termino_pago,
    listar_termino_pago,
    eliminar_termino_pago,
    obtener_termino_pago,
    actualizar_termino_pago,

    registro_itbis,
    listar_itbis,
    eliminar_itbis,
    obtener_itbis,
    actualizar_itbis,

    registro_tipo_ingreso,
    listar_tipo_ingreso,
    eliminar_tipo_ingreso,
    obtener_tipo_ingreso,
    actualizar_tipo_ingreso,
}