'use strict'

var fs = require('fs');
var path = require('path');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../helpers/jwt');
const puppeteer = require('puppeteer');

var Log = require('../models/log');
var Log_Item = require('../models/log_item');

var LogController = require('../controllers/generalController');

var Modulo = require('../models/modulo');
var Sucursal = require('../models/sucursal');
var Pagina = require('../models/pagina');
var Usuario = require('../models/usuario');
var Rol = require('../models/rol');
var Rol_Aceeso = require('../models/rol_acceso');
var Companias = require('../models/compania');
var Idioma = require('../models/idioma');

var Cliente = require('../models/cliente');
var Ticket = require('../models/ticket');
//Companias
const registro_compania = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'companias' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    let reg = await Companias.create(data);

                    //Log
                    LogController.log_create("companias", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    }
    catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_compania = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'companias' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Companias.find();
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        console.log(error)
        res.status(400).send({ message: error });
    }
}

const eliminar_compania = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'companias' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                //let reg = await Companias.findByIdAndRemove({ _id: id });

                //Log de eliminar
                //LogController.log_delete("companias", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: 'No se puede eliminar la compania' });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_compania = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'companias' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Companias.findById({ _id: id }).populate('moneda_curso').populate('moneda_paralela').
                        exec(function (err, company) {
                            if (err) {
                                console.log(err);
                            }
                            res.status(200).send({ data: company });
                        });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_compania = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'companias' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Companias.findByIdAndUpdate({ _id: id }, data);
                
                //Log de actualizar
                LogController.log_edit("companias", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(200).send({ message: error });
    }
}

//Sucursales
const registro_sucursal = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'sucursales' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {

                var data = req.body;
                data.compania = req.user.compania;
                let reg = await Sucursal.create(data);

                //log de Registro
                LogController.log_create("sucursales", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_sucursales = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'sucursales' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Sucursal.find({ compania: req.user.compania, descripcion: new RegExp(filtro, 'i') }).populate('compania');
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_sucursal = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'sucursales' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                //let reg = await Sucursal.findByIdAndRemove({ _id: id });

                //Log de eliminar
                //LogController.log_delete("sucursales", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: 'No se puede eliminar la sucursal' });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_sucursal = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'sucursales' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Sucursal.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_sucursal = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'sucursales' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                
                let id = req.params['id'];
                var data = req.body;

                let reg = await Sucursal.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("sucursales", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Modulos
const registro_modulo = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'modulos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Modulo.create(data);

                //Log
                LogController.log_create("modulos", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_modulo = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'modulos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Modulo.find({ descripcion: new RegExp(filtro, 'i') });
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_modulo = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'modulos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                //let reg = await Modulo.findByIdAndRemove({ _id: id });

                //Eliminar todas las páginas relacionadas
                //await Pagina.remove({ modulo: id });

                //Log de eliminar
                //LogController.log_delete("modulos", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: 'No se puede eliminar la compania' });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_modulo = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'modulos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Modulo.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_modulo = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'modulos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Modulo.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("modulos", data, req.user.sub, req.user.compania, reg._id);
                
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Paginas
const registro_pagina = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'paginas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                let reg = await Pagina.create(data);

                //Log
                LogController.log_create("paginas", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_pagina = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'paginas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Pagina.find({ descripcion: new RegExp(filtro, 'i') }).populate('modulo');
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_pagina = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'paginas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Pagina.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("paginas", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_pagina = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'paginas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Pagina.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_pagina = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'paginas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Pagina.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("paginas", data, req.user.sub, req.user.compania, reg._id);
                
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Usuario
const registro_usuario = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'usuarios' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;
                var usuario_arr = [];

                usuario_arr = await Usuario.find({ email: data.email });

                if (usuario_arr.length == 0) {
                    if (data.password) {
                        bcrypt.hash(data.password, null, null, async function (err, hash) {
                            if (hash) {
                                data.password = hash;
                                data.compania = req.user.compania;
                                var reg = await Usuario.create(data);

                                //Log
                                LogController.log_create("usuarios", data, req.user.sub, req.user.compania, reg._id);
                                
                                res.status(200).send({ data: reg });
                            }
                            else {
                                res.status(200).send({ message: 'Error Server', data: undefined });
                            }
                        })
                    }
                    else {
                        res.status(200).send({ message: 'No existe una contraseña', data: undefined });
                    }
                }
                else {
                    res.status(200).send({ message: 'El correo ya existe en la base de datos', data: undefined });
                }
            }
            else {
                res.status(200).send({ message: 'El usuario debe ser Administrador del sistema', data: undefined });
            }
        } else {
            res.status(200).send({ message: 'Debe autenticarse', data: undefined });
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({ message: error });
    }
}

const listar_usuario = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'usuarios' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Usuario.find({ compania: req.user.compania }).populate('rol').populate('compania');
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_usuario = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'usuarios' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let usuario = await Usuario.findById({ _id: id });
                
                //Inhabilitar usuario
                usuario.estatus = false;

                let reg = await Usuario.findByIdAndUpdate({ _id: id }, usuario);

                //Log de eliminar
                LogController.log_delete("usuarios", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_usuario = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'usuarios' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Usuario.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_usuario = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'usuarios' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                if (data.password) {
                    bcrypt.hash(data.password, null, null, async function (err, hash) {
                        if (hash) {
                            data.password = hash;
                        }
                        else {
                            res.status(200).send({ message: 'Error Server', data: undefined });
                        }
                    })
                }

                let reg = await Usuario.findByIdAndUpdate({ _id: id }, data);
                
                //Log de actualizar
                LogController.log_edit("usuarios", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const login_admin = async function (req, res) {
    try {
        var data = req.body;
        var usuario_arr = [];

        usuario_arr = await Usuario.find({ email: data.email });
        console.log(data.email);
        if (usuario_arr.length == 0) {
            res.status(200).send({ code: 1001, message: 'No se encontró el correo', data: undefined });
        }
        else {
            let user = usuario_arr[0];
            if(user.estatus == true)
            {
                bcrypt.compare(data.password, user.password, async function (error, check) {
                    if (check) {
                        res.status(200).send({
                            data: user,
                            token: jwt.createToken(user)
                        });
                    }
                    else {
                        res.status(200).send({ code: 1002, message: 'La contraseña no coincide', data: undefined });
                    }
                });
            }
            else{
                res.status(200).send({ code: 1003, message: 'Este usuario está inactivo', data: undefined });
            }
            
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
};

//Roles
const registro_rol = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {
                var data = req.body;

                data.compania = req.user.compania;
                let reg = await Rol.create(data);

                //Log
                LogController.log_create("roles", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_roles = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Rol.find({ compania: req.user.compania, descripcion: new RegExp(filtro, 'i') }).populate('compania');
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_rol = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Rol.findByIdAndRemove({ _id: id });
                LogController.log_delete("roles", req.user.sub, req.user.compania, reg._id);

                //Eliminar los accesos de ese rol
                let reg_acceso = await Rol_Aceeso.findByIdAndRemove({ rolShema: reg._id });
                LogController.log_delete("roles", req.user.sub, req.user.compania, reg_acceso._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_rol = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Rol.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_rol = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Rol.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("roles", data, req.user.sub, req.user.compania, reg._id);
                
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Roles Acceso
const registro_rol_acceso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles_accesos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].add == true) {

                var data = req.body;
                data.compania = req.user.compania;
                let reg = await Rol_Aceeso.create(data);

                //Log
                LogController.log_create("roles_accesos", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_roles_acceso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles_accesos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                let filtro = req.params['filtro'];

                let reg = await Rol_Aceeso.find({ compania: req.user.compania, descripcion: new RegExp(filtro, 'i') }).populate('modulo').populate('pagina');
                res.status(200).send({ data: reg });

            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({ message: error });
    }
}

const eliminar_rol_acceso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles_accesos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].delete == true) {
                var id = req.params['id'];

                let reg = await Rol_Aceeso.findByIdAndRemove({ _id: id });

                //Log de eliminar
                LogController.log_delete("roles_accesos", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({ data: reg });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_rol_acceso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles_accesos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].read == true) {
                var id = req.params['id'];
                try {
                    var reg = await Rol_Aceeso.findById({ _id: id });

                    res.status(200).send({ data: reg });
                }
                catch (error) {
                    res.status(200).send({ data: undefined });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_rol_acceso = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'roles_accesos' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos.acceso[0].edit == true) {
                let id = req.params['id'];
                var data = req.body;

                let reg = await Rol_Aceeso.findByIdAndUpdate({ _id: id }, data);

                //Log de actualizar
                LogController.log_edit("roles_accesos", data, req.user.sub, req.user.compania, reg._id);
                res.status(200).send({ data: data });
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Idiomas
const registro_idioma = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'idiomas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].add == true) {
                    var data = req.body;

                    data.compania = req.user.compania;
                    let reg = await Idioma.create(data);

                    //Log
                    LogController.log_create("idiomas", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const listar_idioma = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'idiomas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    let filtro = req.params['filtro'];

                    let reg = await Idioma.find({ compania: req.user.compania, descripcion: new RegExp(filtro, 'i') });
                    res.status(200).send({ data: reg });

                } else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            } else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const eliminar_idioma = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'idiomas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].delete == true) {
                    var id = req.params['id'];

                    let reg = await Idioma.findByIdAndRemove({ _id: id });

                    //Log de eliminar
                    LogController.log_delete("idiomas", req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({ data: reg });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const obtener_idioma = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'idiomas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        var reg = await Idioma.findById({ _id: id });

                        res.status(200).send({ data: reg });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

const actualizar_idioma = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'idiomas' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].edit == true) {
                    let id = req.params['id'];
                    var data = req.body;

                    let reg = await Idioma.findByIdAndUpdate({ _id: id }, data);
                    
                    //Log de actualizar
                    LogController.log_edit("idiomas", data, req.user.sub, req.user.compania, reg._id);
                    res.status(200).send({ data: data });
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Menu
const listar_menu = async function (req, res) {
    try {
        if (req.user) {
            var moduloArray = {
                modulo: [{
                    paginas: []
                }]
            };
            let accesos = await Rol_Aceeso.find({ rol: req.user.role, compania: req.user.compania }).populate('pagina').populate('modulo');

            //await moduloArr.forEach(async item => {
            //    let paginasT = Pagina.find({modulo: item._id});
            //    moduloArray.modulo.push({id: item._id, descripcion:item.descripcion, paginas: paginasT});
            //});

            accesos.forEach(item => {
                moduloArray.modulo.push({ id: item.pagina._id, descripcion: item.pagina.descripcion, acceso: item.acceso });
            });

            res.status(200).send({ data: accesos });
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Log
const consultar_log = async function (req, res) {
    try {
        if (req.user) {
            let pagina = await Pagina.findOne({ code: 'logs' });
            let accesos = await Rol_Aceeso.findOne({ compania: req.user.compania, rol: req.user.role, pagina: pagina._id });
            if (accesos != null) {
                if (accesos.acceso[0].read == true) {
                    var id = req.params['id'];
                    try {
                        console.log(id);
                        var log_item = await Log_Item.findOne({ id: id });

                        var log_header = await Log.findOne({ compania: req.user.compania, log_item: log_item._id }).populate('log_item');

                        res.status(200).send({ data: log_item });
                    }
                    catch (error) {
                        res.status(200).send({ data: undefined });
                    }
                }
                else {
                    res.status(500).send({ message: 'NoAccess' });
                }
            }
            else {
                res.status(500).send({ message: 'NoAccess' });
            }
        } else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Consultar cedula
const consultar_cedula = async function (req, res) {
    try {
        if (req.user) {
            try {
                //Leer parametro de cedula
                let cedula = req.params['cedula'];

                let cliente = await Cliente.findOne({ documento: cedula });

                if (cliente != null) {
                    let result = {
                        _id: cliente._id,
                        nombre: cliente.nombre,
                        telefono: cliente.telefono,
                        compania: req.user.compania,
                        documento: cliente.documento
                    }
                    res.status(200).send({ data: result });
                }
                else {
                    //Inicializar variables
                    const browser = await puppeteer.launch();
                    const page = await browser.newPage();

                    //Dirigirnos a la pagina
                    await page.goto('https://dgii.gov.do/app/WebApps/ConsultasWeb/consultas/ciudadanos.aspx', { waitUntil: 'networkidle2' });
                    //Colocar cedula
                    await page.type('#ctl00_cphMain_txtCedula', cedula);
                    //Clickear boton de buscar 
                    await page.click('#ctl00_cphMain_btnBuscarCedula');
                    //Esperar resultado
                    try {
                        await page.waitForSelector('#ctl00_cphMain_dvResultadoCedula', { timeout: 3000 });
                        let nombre = await page.$eval('#ctl00_cphMain_dvResultadoCedula tbody tr:first-child td:nth-child(2)', td => td.innerText);
                        //Cerrar conexion
                        await browser.close();

                        let result = {
                            nombre: nombre,
                            documento: cedula
                        }

                        res.status(200).send({ data: result });
                    } catch (e) {
                        await page.waitForSelector('#ctl00_cphMain_divAlertDanger');
                        let message = await page.$eval('#ctl00_cphMain_divAlertDanger', el => el.innerText);
                        res.status(400).send({ message });
                    }

                }
            }
            catch (error) {
                console.log(error);
                res.status(200).send({ data: undefined });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        res.status(400).send({ message: error });
    }
}

//Guardar cliente dispositivo
const guardar_cliente_dispositivo = async function (req, res) {
    try {
        if (req.user) {
            try {
                //Leer body
                var data = req.body;
                let cliente = await Cliente.findOne({ documento: data.documento });
                if(cliente){
                    data._id = cliente._id;
                }
                if (data._id) {
                    let reg = await Cliente.findByIdAndUpdate({ _id: data._id }, data);

                    let ticket = {
                        compania: req.user.compania,
                        cliente: reg._id,
                        estatus: true
                    }
                    
                    var data = await crear_ticket(ticket);

                    //Log
                    LogController.log_create("ticket", data, req.user.sub, req.user.compania, data._id);

                    if(data != null){
                        res.status(200).send({ data: data });
                    }
                    else{
                        res.status(400).send({ message: "Error al crear el ticket" });
                    }
                }
                else {
                    data.compania = req.user.compania;
                    data.descripcion = data.nombre;
                    data.estatus = true;
                    let reg = await Cliente.create(data);

                    let ticket = {
                        compania: req.user.compania,
                        cliente: reg._id,
                        estatus: true
                    }

                    var data = await crear_ticket(ticket);

                    if(data != null){
                        res.status(200).send({ data: data });
                    }
                    else{
                        res.status(400).send({ message: "Error al crear el ticket" });
                    }

                }
            }
            catch (error) {
                console.log(error);
                res.status(200).send({ message: error });
            }
        }
        else {
            res.status(500).send({ message: 'NoAccess' });
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({ message: error });
    }
}

//Crear ticket
const crear_ticket = async function (data) {
    try {
        //Fecha today
        const today = new Date();
        const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);

        //Buscar ticket anteriores
        let ticket_anterior = await Ticket.findOne({ fecha: { $gte: start, $lt: end } }).sort({ code: -1 });

        //Buscar el más alto
        if (ticket_anterior != null) {
            data.code = ticket_anterior.code + 1;
        }
        else {
            data.code = 1;
        }

        let reg = await Ticket.create(data);

        return reg

    } catch (error) {
        console.log(error);
    }
}
module.exports = {
    //modulos
    registro_modulo,
    listar_modulo,
    eliminar_modulo,
    obtener_modulo,
    actualizar_modulo,

    //Paginas
    registro_pagina,
    listar_pagina,
    eliminar_pagina,
    obtener_pagina,
    actualizar_pagina,

    //Usuarios
    registro_usuario,
    listar_usuario,
    eliminar_usuario,
    obtener_usuario,
    actualizar_usuario,
    login_admin,

    //Roles
    registro_rol,
    listar_roles,
    eliminar_rol,
    obtener_rol,
    actualizar_rol,

    //Role Pagina 
    registro_rol_acceso,
    listar_roles_acceso,
    eliminar_rol_acceso,
    obtener_rol_acceso,
    actualizar_rol_acceso,

    //Companias
    registro_compania,
    listar_compania,
    eliminar_compania,
    obtener_compania,
    actualizar_compania,

    //Sucursales
    registro_sucursal,
    listar_sucursales,
    eliminar_sucursal,
    obtener_sucursal,
    actualizar_sucursal,

    //Idiomas
    registro_idioma,
    listar_idioma,
    eliminar_idioma,
    obtener_idioma,
    actualizar_idioma,

    listar_menu,

    consultar_log,

    consultar_cedula,

    crear_ticket,

    guardar_cliente_dispositivo
}