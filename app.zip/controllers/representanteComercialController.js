'use strict'

var fs = require('fs');
var path = require('path');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../helpers/jwt');

var Pagina = require('../models/pagina');
var Rol_Aceeso = require('../models/rol_acceso');

var Cliente = require('../models/cliente');
var Proveedor = require('../models/proveedor');
var Doctor = require('../models/doctor');

var Tickets = require('../models/ticket');
var Venta = require('../models/venta');
//Clientes
const registro_cliente = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'clientes'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
                if(accesos.acceso[0].add == true){
                    var data = req.body;

                    data.compania = req.user.compania;
                    let reg = await Cliente.create(data);

                    //log de Registro
                    LogController.log_create("clientes", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({data:reg});
                }
                else{
                    res.status(500).send({message: 'NoAccess'});
                }
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const listar_cliente = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'clientes'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                let filtro = req.params['filtro'];

                let reg = await Cliente.find({descripcion: new RegExp(filtro, 'i')}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");
                res.status(200).send({data:reg});
                
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const eliminar_cliente = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'clientes'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].delete == true){
                var id = req.params['id'];

                var tickets_arr = [];
                var ventas_arr = [];

                //Tickets
                tickets_arr = await Tickets.find({ cliente: id });
                if (tickets_arr.length == 0) {

                    //Ventas
                    ventas_arr = await Venta.find({ cliente: id });
                    if (ventas_arr.length == 0) {
                        let reg = await Cliente.findByIdAndRemove({_id:id});

                        //Log de eliminar
                        LogController.log_delete("clientes", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({data:reg});
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar este cliente, existen (' + ventas_arr.length + ') ventas con este cliente', data: undefined });
                    }
                }
                else {
                    res.status(200).send({ code: 1004, message: 'No se puede eliminar este cliente, existen (' + tickets_arr.length + ') tickets con este cliente', data: undefined });
                }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const obtener_cliente = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'clientes'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                var id = req.params['id'];
                try {
                    var reg = await Cliente.findById({_id:id}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");

                    res.status(200).send({data:reg});
                } 
                catch (error) {
                    res.status(200).send({data:undefined});
                }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }
        else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const actualizar_cliente = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'clientes'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].edit == true){
                let id = req.params['id'];
                var data = req.body;

                let reg = await Cliente.findByIdAndUpdate({_id:id},data);

                //Log de actualizar
                LogController.log_edit("clientes", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:data});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

//Doctor
const registro_doctor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'doctor'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
                if(accesos.acceso[0].add == true){
                    var data = req.body;
                    
                    data.compania = req.user.compania;
                    let reg = await Doctor.create(data);

                    //log de Registro
                    LogController.log_create("doctor", data, req.user.sub, req.user.compania, reg._id);

                    res.status(200).send({data:reg});
                }
                else{
                    res.status(500).send({message: 'NoAccess'});
                }
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const listar_doctor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'doctor'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                let filtro = req.params['filtro'];

                let reg = await Doctor.find({descripcion: new RegExp(filtro, 'i')}).populate("tipo_documento");
                res.status(200).send({data:reg});
                
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({message: error});
    }
}

const eliminar_doctor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'doctor'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].delete == true){
                var id = req.params['id'];

                var ventas_arr = [];

                ventas_arr = await Venta.find({ doctor: id });
    
                    if (ventas_arr.length == 0) {
                        let reg = await Doctor.findByIdAndRemove({_id:id});

                        //Log de eliminar
                        LogController.log_delete("doctor", req.user.sub, req.user.compania, reg._id);

                        res.status(200).send({data:reg});
                    }
                    else {
                        res.status(200).send({ code: 1004, message: 'No se puede eliminar este doctor, existen (' + ventas_arr.length + ') ventas con este doctor', data: undefined });
                    }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const obtener_doctor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'doctor'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                var id = req.params['id'];
                try {
                    var reg = await Doctor.findById({_id:id}).populate("tipo_documento");

                    res.status(200).send({data:reg});
                } 
                catch (error) {
                    res.status(200).send({data:undefined});
                }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }
        else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const actualizar_doctor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'doctor'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].edit == true){
                let id = req.params['id'];
                var data = req.body;

                let reg = await Doctor.findByIdAndUpdate({_id:id},data);

                //Log de actualizar
                LogController.log_edit("doctor", data, req.user.sub, req.user.compania, reg._id);
                
                res.status(200).send({data:data});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

//Proveedores
const registro_proveedor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'proveedores'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].add == true){
                var data = req.body;
                
                let reg = await Proveedor.create(data);

                //log de Registro
                LogController.log_create("proveedores", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:reg});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const listar_proveedor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'proveedores'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                let filtro = req.params['filtro'];

                let reg = await Proveedor.find({descripcion: new RegExp(filtro, 'i')}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");
                res.status(200).send({data:reg});
                
            }else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const eliminar_proveedor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'proveedores'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].delete == true){
                var id = req.params['id'];

                let reg = await Proveedor.findByIdAndRemove({_id:id});

                //Log de eliminar
                LogController.log_delete("proveedores", req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:reg});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const obtener_proveedor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'proveedores'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].read == true){
                var id = req.params['id'];
                try {
                    var reg = await Proveedor.findById({_id:id}).populate("tipo_cliente").populate("tipo_documento").populate("termino_pago");

                    res.status(200).send({data:reg});
                } 
                catch (error) {
                    res.status(200).send({data:undefined});
                }
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }
        else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}

const actualizar_proveedor = async function(req, res){
    try {
        if(req.user){
            let pagina = await Pagina.findOne({code: 'proveedores'});
            let accesos = await Rol_Aceeso.findOne({compania: req.user.compania, rol:req.user.role, pagina: pagina._id});
            if(accesos != null)
            {
            if(accesos.acceso[0].edit == true){
                let id = req.params['id'];
                var data = req.body;

                let reg = await Proveedor.findByIdAndUpdate({_id:id},data);

                //Log de actualizar
                LogController.log_edit("proveedores", data, req.user.sub, req.user.compania, reg._id);

                res.status(200).send({data:data});
            }
            else{
                res.status(500).send({message: 'NoAccess'});
            }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
        }else{
            res.status(500).send({message: 'NoAccess'});
        }
    } catch (error) {
        res.status(400).send({message: error});
    }
}
module.exports = {
registro_cliente,
listar_cliente,
eliminar_cliente,
obtener_cliente,
actualizar_cliente,

registro_proveedor,
listar_proveedor,
eliminar_proveedor,
obtener_proveedor,
actualizar_proveedor,

registro_doctor,
listar_doctor,
eliminar_doctor,
obtener_doctor,
actualizar_doctor
}