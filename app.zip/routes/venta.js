'use strict'

var express = require('express');

var VentaController = require('../controllers/ventaController');

var api = express.Router();
var auth = require('../milddlewares/authenticate');
var multiparty = require('connect-multiparty');
var path = multiparty({uploadDir: './uploads/representante_comercial'});

//Venta
api.post('/registro_venta',[auth.auth], VentaController.registro_venta);
api.get('/listar_venta/:filtro?',[auth.auth], VentaController.listar_venta);
api.delete('/eliminar_venta/:id',auth.auth, VentaController.eliminar_venta);
api.get('/obtener_venta/:id',[auth.auth], VentaController.obtener_venta);
api.put('/actualizar_venta/:id',[auth.auth], VentaController.actualizar_venta);

module.exports = api;