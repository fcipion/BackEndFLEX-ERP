'use strict'

var express = require('express');

var RepresentanteComercialController = require('../controllers/representanteComercialController');

var api = express.Router();
var auth = require('../milddlewares/authenticate');
var multiparty = require('connect-multiparty');
var path = multiparty({uploadDir: './uploads/representante_comercial'});

//Clientes
api.post('/registro_cliente',[auth.auth], RepresentanteComercialController.registro_cliente);
api.get('/listar_cliente/:filtro?',[auth.auth], RepresentanteComercialController.listar_cliente);
api.delete('/eliminar_cliente/:id',auth.auth, RepresentanteComercialController.eliminar_cliente);
api.get('/obtener_cliente/:id',[auth.auth], RepresentanteComercialController.obtener_cliente);
api.put('/actualizar_cliente/:id',[auth.auth], RepresentanteComercialController.actualizar_cliente);

//Proveedores
api.post('/registro_proveedor',[auth.auth], RepresentanteComercialController.registro_proveedor);
api.get('/listar_proveedor/:filtro?',[auth.auth], RepresentanteComercialController.listar_proveedor);
api.delete('/eliminar_proveedor/:id',auth.auth, RepresentanteComercialController.eliminar_proveedor);
api.get('/obtener_proveedor/:id',[auth.auth], RepresentanteComercialController.obtener_proveedor);
api.put('/actualizar_proveedor/:id',[auth.auth], RepresentanteComercialController.actualizar_proveedor);

//Doctor
api.post('/registro_doctor',[auth.auth], RepresentanteComercialController.registro_doctor);
api.get('/listar_doctor/:filtro?',[auth.auth], RepresentanteComercialController.listar_doctor);
api.delete('/eliminar_doctor/:id',auth.auth, RepresentanteComercialController.eliminar_doctor);
api.get('/obtener_doctor/:id',[auth.auth], RepresentanteComercialController.obtener_doctor);
api.put('/actualizar_doctor/:id',[auth.auth], RepresentanteComercialController.actualizar_doctor);

module.exports = api;