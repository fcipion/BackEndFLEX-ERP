'use strict'

var express = require('express');

var AdministracionController = require('../controllers/administracionController');

var api = express.Router();
var auth = require('../milddlewares/authenticate');
var multiparty = require('connect-multiparty');
var path = multiparty({uploadDir: './uploads/productos'});

//Companias
api.post('/registro_compania',[auth.auth], AdministracionController.registro_compania);
api.get('/listar_compania/:filtro?',[auth.auth], AdministracionController.listar_compania);
api.delete('/eliminar_compania/:id',auth.auth, AdministracionController.eliminar_compania);
api.get('/obtener_compania/:id',[auth.auth], AdministracionController.obtener_compania);
api.put('/actualizar_compania/:id',[auth.auth], AdministracionController.actualizar_compania);

//Sucursales
api.post('/registro_sucursal',[auth.auth], AdministracionController.registro_sucursal);
api.get('/listar_sucursales/:filtro?',[auth.auth], AdministracionController.listar_sucursales);
api.delete('/eliminar_sucursal/:id',auth.auth, AdministracionController.eliminar_sucursal);
api.get('/obtener_sucursal/:id',[auth.auth], AdministracionController.obtener_sucursal);
api.put('/actualizar_sucursal/:id',[auth.auth], AdministracionController.actualizar_sucursal);

//Modulos
api.post('/registro_modulo',[auth.auth], AdministracionController.registro_modulo);
api.get('/listar_modulo/:filtro?',[auth.auth], AdministracionController.listar_modulo);
api.delete('/eliminar_modulo/:id',auth.auth, AdministracionController.eliminar_modulo);
api.get('/obtener_modulo/:id',[auth.auth], AdministracionController.obtener_modulo);
api.put('/actualizar_modulo/:id',[auth.auth], AdministracionController.actualizar_modulo);

//Paginas
api.post('/registro_pagina',[auth.auth], AdministracionController.registro_pagina);
api.get('/listar_pagina/:filtro?',[auth.auth], AdministracionController.listar_pagina);
api.delete('/eliminar_pagina/:id',auth.auth, AdministracionController.eliminar_pagina);
api.get('/obtener_pagina/:id',[auth.auth], AdministracionController.obtener_pagina);
api.put('/actualizar_pagina/:id',[auth.auth], AdministracionController.actualizar_pagina);

//Roles
api.post('/registro_rol',[auth.auth], AdministracionController.registro_rol);
api.get('/listar_roles/:filtro?',[auth.auth], AdministracionController.listar_roles);
api.delete('/eliminar_rol/:id',auth.auth, AdministracionController.eliminar_rol);
api.get('/obtener_rol/:id',[auth.auth], AdministracionController.obtener_rol);
api.put('/actualizar_rol/:id',[auth.auth], AdministracionController.actualizar_rol);

//rol_acceso
api.post('/registro_rol_acceso',[auth.auth], AdministracionController.registro_rol_acceso);
api.get('/listar_roles_acceso/:filtro?',[auth.auth], AdministracionController.listar_roles_acceso);
api.delete('/eliminar_rol_acceso/:id',auth.auth, AdministracionController.eliminar_rol_acceso);
api.get('/obtener_rol_acceso/:id',[auth.auth], AdministracionController.obtener_rol_acceso);
api.put('/actualizar_rol_acceso/:id',[auth.auth], AdministracionController.actualizar_rol_acceso);

//Idiomas
api.post('/registro_idioma',[auth.auth], AdministracionController.registro_idioma);
api.get('/listar_idioma/:filtro?',[auth.auth], AdministracionController.listar_idioma);
api.delete('/eliminar_idioma/:id',auth.auth, AdministracionController.eliminar_idioma);
api.get('/obtener_idioma/:id',[auth.auth], AdministracionController.obtener_idioma);
api.put('/actualizar_idioma/:id',[auth.auth], AdministracionController.actualizar_idioma);

//Menu 
api.get('/listar_menu',[auth.auth], AdministracionController.listar_menu);
api.get('/consultar_log/:id',[auth.auth], AdministracionController.consultar_log);

//Usuario 
api.post('/registro_usuario',[auth.auth], AdministracionController.registro_usuario);
api.get('/listar_usuario/:filtro?',[auth.auth], AdministracionController.listar_usuario);
api.delete('/eliminar_usuario/:id',auth.auth, AdministracionController.eliminar_usuario);
api.get('/obtener_usuario/:id',[auth.auth], AdministracionController.obtener_usuario);
api.put('/actualizar_usuario/:id',[auth.auth], AdministracionController.actualizar_usuario);

//Login
api.post('/login_admin', AdministracionController.login_admin);

//consultar_cedula 
api.post('/consultar_cedula/:cedula?',[auth.auth], AdministracionController.consultar_cedula);

//crear_ticket
api.post('/crear_ticket',[auth.auth], AdministracionController.crear_ticket);

//guardar_cliente_dispositivo
api.post('/guardar_cliente_dispositivo',[auth.auth], AdministracionController.guardar_cliente_dispositivo);
module.exports = api;