'use strict'

var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema;

var determinacionPrecioShema = Schema({
    id: {type: Number, autoIncrement: true, unique: true},
    compania: {type: Schema.ObjectId, ref: 'compania', required: true}, 
    sucursal: {type: Schema.ObjectId, ref: 'sucursal', required: true}, 
    lista_precio: {type: Schema.ObjectId, ref: 'lista_precio', required: true},
    producto: {type: Schema.ObjectId, ref: 'producto', required: true},
    precio: {type: Number, required: true},
    moneda: {type: Schema.ObjectId, ref: 'moneda', required: true},
    estatus: {type: Boolean, required: true},
    createdAt: {type: Date, default: Date.now, require:true},
});

autoIncrement.initialize(mongoose.connection);
determinacionPrecioShema.plugin(autoIncrement.plugin, {model: 'determinacion_precio', field: 'id', startAt: 1});
module.exports = mongoose.model('determinacion_precio', determinacionPrecioShema);