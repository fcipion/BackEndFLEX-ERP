'use strict'

var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema;

var movimientoMercanciaShema = Schema({
    id: {type: Number, autoIncrement: true, unique: true},
    compania: {type: Schema.ObjectId, ref: 'compania', required: true}, 
    sucursal: {type: Schema.ObjectId, ref: 'sucursal', required: true}, 
    almacen: {type: Schema.ObjectId, ref: 'almacen', required: true},
    producto: {type: Schema.ObjectId, ref: 'producto', required: true},
    clase_movimiento: {type: Schema.ObjectId, ref: 'clase_movimiento', required: true},
    cantidad: {type: Number, required: true},
    precio: {type: Number, required: true},
    fecha: {type: Date, default: Date.now, require:true},
    createdAt: {type: Date, default: Date.now, require:true},
});

autoIncrement.initialize(mongoose.connection);
movimientoMercanciaShema.plugin(autoIncrement.plugin, {model: 'movimiento_mercancia', field: 'id', startAt: 1});
module.exports = mongoose.model('movimiento_mercancia', movimientoMercanciaShema);