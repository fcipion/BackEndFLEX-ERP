'use strict'

var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema;

var log_itemShema = Schema({
    id: {type: Number, autoIncrement: true, unique: true},
    changes: [{type: Object, required: true}],
});

autoIncrement.initialize(mongoose.connection);
log_itemShema.plugin(autoIncrement.plugin, {model: 'log_item', field: 'id', startAt: 1});
module.exports = mongoose.model('log_item', log_itemShema);